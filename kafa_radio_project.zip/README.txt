Kafa Radyo - Android project skeleton (Kotlin)

What this includes:
- ExoPlayer-based RadioService for streaming radio.
- Main UI with play/stop and shortcut to Alarm settings.
- Alarm scheduling (weekly) using AlarmManager.
- Simple location-based gate: if 'Sadece evde çal' is set and home coords configured, the alarm checks last-known location distance before starting stream.
- Storage of a single alarm in SharedPreferences (extend as needed).

Important notes & how to build:
1) Open this folder in Android Studio (File -> Open) and let it sync (Gradle).
2) Provide a valid stream URL or leave the default placeholder.
3) The app requests location permissions; for reliable 'home' detection implement geofencing or allow the app to set home location via map UI (currently placeholder).
4) To build APK: Build -> Build Bundle(s) / APK(s) -> Build APK(s).
5) Test on device (location permissions and background permissions may be required).

Limitations in this prototype:
- Home location setting is a placeholder (you should implement a map or manual lat/lon input).
- AlarmStorage currently stores one alarm; extend to multiple alarms as needed.
- This repo does NOT include Gradle wrapper files. Use Android Studio's built-in Gradle or generate wrapper if needed.

